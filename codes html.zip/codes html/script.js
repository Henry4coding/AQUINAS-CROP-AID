function uploadImage() {
    alert("Image upload and detection feature coming soon!");
}
